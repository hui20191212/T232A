/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 5.5.36 : Database - p2p
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`p2p` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `p2p`;

/*Table structure for table `account` */

DROP TABLE IF EXISTS `account`;

CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `banknumber` varchar(100) DEFAULT NULL COMMENT '银行卡号',
  `accountbalance` varchar(100) DEFAULT NULL COMMENT '账户余额',
  `accountpwd` varchar(100) DEFAULT NULL COMMENT '支付密码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `account` */

/*Table structure for table `askfor` */

DROP TABLE IF EXISTS `askfor`;

CREATE TABLE `askfor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `ename` varchar(300) DEFAULT NULL,
  `phone` varchar(300) DEFAULT NULL,
  `money` int(11) DEFAULT NULL,
  `mdate` int(11) DEFAULT NULL,
  `pinterest` float DEFAULT NULL,
  `pservice` int(11) DEFAULT NULL,
  `mtype` int(11) DEFAULT NULL,
  `mresult` int(11) DEFAULT NULL,
  `sysusername` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `askfor` */

insert  into `askfor`(`id`,`pid`,`userid`,`ename`,`phone`,`money`,`mdate`,`pinterest`,`pservice`,`mtype`,`mresult`,`sysusername`) values (7,2,11,'曹广辉','18674736389',3000,4,0.3,150,2,NULL,NULL),(8,2,11,'曹广辉','18674736389',5000,4,0.3,150,1,NULL,NULL),(9,2,11,'曹广辉','18674736389',1000,4,0.3,150,1,NULL,NULL),(10,2,11,'曹广辉','18674736389',1000,4,0.3,150,1,NULL,NULL),(11,1,11,'曹广辉','18674736389',1000,4,0.3,102,1,NULL,NULL),(12,1,13,'陈鹏飞','17773914768',3000,4,0.3,102,2,NULL,NULL),(13,1,13,'陈鹏飞','17773914768',5000,4,0.3,102,2,NULL,NULL),(14,1,11,'曹广辉','18674736389',3000,4,0.3,102,2,NULL,NULL);

/*Table structure for table `basic` */

DROP TABLE IF EXISTS `basic`;

CREATE TABLE `basic` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `userid` int(11) NOT NULL COMMENT '用户id',
  `ename` varchar(100) DEFAULT NULL COMMENT '客户姓名',
  `phone` varchar(100) DEFAULT NULL COMMENT '用户电话',
  `cardNo` varchar(100) DEFAULT NULL COMMENT '身份证号码',
  `cardimagez` varchar(100) DEFAULT NULL COMMENT '身份证正面照  图片表file_id',
  `cardimageh` varchar(100) DEFAULT NULL COMMENT '身份证背面照  图片表file_id',
  `userimage` varchar(100) DEFAULT NULL COMMENT '本人正面照  图片表file_id',
  `result` int(11) DEFAULT NULL COMMENT '申请结果',
  `sysusername` varchar(100) DEFAULT NULL COMMENT '审核人姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `basic` */

insert  into `basic`(`id`,`userid`,`ename`,`phone`,`cardNo`,`cardimagez`,`cardimageh`,`userimage`,`result`,`sysusername`) values (2,11,'曹广辉','18674736389','430482200012266379',NULL,NULL,NULL,NULL,NULL),(3,13,'陈鹏飞','17773914768','',NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `contract` */

DROP TABLE IF EXISTS `contract`;

CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '开始时间',
  `jiedate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '截至时间',
  `pinterest` float DEFAULT NULL COMMENT '产品利息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `contract` */

insert  into `contract`(`id`,`createdate`,`jiedate`,`pinterest`) values (1,'2019-12-02 17:05:08','2019-12-03 17:05:03',0.2),(2,'2019-12-09 11:53:21','2020-04-11 11:53:21',0.3),(3,'2019-12-09 13:33:03','2020-04-11 13:33:03',0.3),(4,'2019-12-09 23:17:58','2020-04-11 23:17:58',0.1),(5,'2019-12-10 09:55:15','2020-04-12 09:55:15',0.1);

/*Table structure for table `dict` */

DROP TABLE IF EXISTS `dict`;

CREATE TABLE `dict` (
  `did` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `id` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `text` varchar(100) DEFAULT NULL,
  `value` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

/*Data for the table `dict` */

insert  into `dict`(`did`,`id`,`pid`,`text`,`value`) values (1,10,-1,'借款额度',NULL),(2,20,-1,'借款时长',NULL),(3,1001,10,'1000','1000'),(4,1002,10,'2000','2000'),(6,2001,20,'3个月','3'),(7,2002,20,'6个月','6'),(8,30,-1,'审核状态',NULL),(12,3001,30,'通过','1'),(14,3002,30,'不通过','2'),(16,1004,10,'3000','3000'),(17,1005,10,'4000','4000'),(18,1006,10,'5000','5000'),(19,31,-1,'任务类型',NULL),(20,3101,31,'基本信息认证','1'),(21,3102,31,'贷款申请','2');

/*Table structure for table `examine` */

DROP TABLE IF EXISTS `examine`;

CREATE TABLE `examine` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `userid` int(11) NOT NULL COMMENT '用户id',
  `ename` varchar(100) DEFAULT NULL COMMENT '客户姓名',
  `phone` varchar(100) DEFAULT NULL COMMENT '用户电话',
  `cardNo` varchar(100) DEFAULT NULL COMMENT '身份证号码',
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '申请时间',
  `etype` int(11) DEFAULT NULL COMMENT '任务类型',
  `STATUS` int(11) DEFAULT NULL COMMENT '审核状态',
  `sysuserid` int(11) DEFAULT NULL COMMENT '审核人id',
  `sysusername` varchar(100) DEFAULT NULL COMMENT '审核人姓名',
  `aid` int(11) DEFAULT NULL COMMENT '贷款申请表id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

/*Data for the table `examine` */

insert  into `examine`(`id`,`userid`,`ename`,`phone`,`cardNo`,`createdate`,`etype`,`STATUS`,`sysuserid`,`sysusername`,`aid`) values (1,1,'李莹','19918222565','431102200012213448','2019-11-28 14:03:48',2,2,NULL,'libiao',NULL),(2,2,'熊欢','13143883732','430482200010012233','2019-11-28 16:21:40',1,2,NULL,'hui',NULL),(7,11,'曹广辉','18674736389','430482200012266379','2019-12-08 15:31:26',1,3,NULL,'hui',2),(10,11,'曹广辉','18674736389','430482200012266379','2019-12-08 22:42:28',2,5,NULL,'hui',7),(11,11,'曹广辉','18674736389','430482200012266379','2019-12-09 13:27:51',2,5,NULL,'hui',8),(12,11,'曹广辉','18674736389','430482200012266379','2019-12-09 13:44:17',2,5,NULL,'hui',9),(13,11,'曹广辉','18674736389','430482200012266379','2019-12-09 17:33:01',2,6,NULL,'hui',10),(14,11,'曹广辉','18674736389','430482200012266379','2019-12-09 23:15:29',2,5,NULL,'hui',11),(15,13,'陈鹏飞','17773914768','','2019-12-10 09:41:43',1,3,NULL,'hui',3),(16,13,'陈鹏飞','17773914768','43052319990915091X','2019-12-10 09:49:45',2,6,NULL,'hui',12),(17,13,'陈鹏飞','17773914768','43052319990915091X','2019-12-10 09:51:35',2,3,NULL,'hui',13),(18,11,'曹广辉','18674736389','430482200012266379','2019-12-10 09:53:28',2,5,NULL,'hui',14);

/*Table structure for table `finance` */

DROP TABLE IF EXISTS `finance`;

CREATE TABLE `finance` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `bmoney` float DEFAULT NULL COMMENT '本金',
  `jmoney` float DEFAULT NULL COMMENT '借出',
  `smoney` float DEFAULT NULL COMMENT '收入',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `finance` */

insert  into `finance`(`id`,`bmoney`,`jmoney`,`smoney`) values (1,1000000000,12000,10000);

/*Table structure for table `finances` */

DROP TABLE IF EXISTS `finances`;

CREATE TABLE `finances` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `money` float DEFAULT NULL COMMENT '金额',
  `ftype` int(11) DEFAULT NULL COMMENT '类型',
  `fdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `finances` */

insert  into `finances`(`id`,`money`,`ftype`,`fdate`) values (3,3000,1,'2019-12-09 11:53:21'),(5,5000,1,'2019-12-09 13:33:03'),(6,1000,1,'2019-12-09 23:17:58'),(7,3000,1,'2019-12-10 09:55:15');

/*Table structure for table `journal` */

DROP TABLE IF EXISTS `journal`;

CREATE TABLE `journal` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `userid` int(10) NOT NULL COMMENT '用户id',
  `targetName` varchar(100) DEFAULT NULL COMMENT '控制器名',
  `methodName` varchar(100) DEFAULT NULL COMMENT '方法名',
  `operteContent` varchar(100) DEFAULT NULL COMMENT '操作说明',
  `jtype` int(10) DEFAULT NULL COMMENT '类型',
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `journal` */

/*Table structure for table `money` */

DROP TABLE IF EXISTS `money`;

CREATE TABLE `money` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `userid` int(11) NOT NULL COMMENT '用户id',
  `quota` int(11) DEFAULT '0' COMMENT '借款额度',
  `moneycount` int(11) DEFAULT '0' COMMENT '资金总额',
  `kejiemoney` int(11) DEFAULT '0' COMMENT '可接金额',
  `daishoumoney` int(11) DEFAULT '0' COMMENT '待收金额',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `money` */

insert  into `money`(`id`,`userid`,`quota`,`moneycount`,`kejiemoney`,`daishoumoney`) values (1,11,10000,8311,-6000,7000);

/*Table structure for table `money_history` */

DROP TABLE IF EXISTS `money_history`;

CREATE TABLE `money_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `userid` int(11) NOT NULL COMMENT '用户id',
  `moneydate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '时间',
  `moneytype` varchar(100) DEFAULT NULL COMMENT '类型',
  `cmoney` int(11) DEFAULT NULL COMMENT '存入',
  `zmoney` int(11) DEFAULT NULL COMMENT '支出',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

/*Data for the table `money_history` */

insert  into `money_history`(`id`,`userid`,`moneydate`,`moneytype`,`cmoney`,`zmoney`) values (1,11,'2019-12-06 08:31:21','提现',0,1000),(3,11,'2019-12-09 11:53:21','收入',3000,0),(4,11,'2019-12-09 13:33:03','收入',5000,0),(5,11,'2019-12-09 20:15:12','支出',0,1012),(6,11,'2019-12-09 20:16:55','支出',0,1012),(7,11,'2019-12-09 23:17:58','收入',1000,0),(8,11,'2019-12-10 09:55:15','收入',3000,0),(9,11,'2019-12-10 09:58:32','支出',0,1662);

/*Table structure for table `p_user` */

DROP TABLE IF EXISTS `p_user`;

CREATE TABLE `p_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `username` varchar(100) DEFAULT NULL COMMENT '用户账号',
  `loginpassword` varchar(100) DEFAULT NULL COMMENT '登录密码',
  `paypassword` varchar(100) DEFAULT NULL COMMENT '支付密码',
  `salt` varchar(100) NOT NULL COMMENT '盐',
  `realname` varchar(100) DEFAULT NULL COMMENT '用户真实名字',
  `phone` varchar(100) NOT NULL COMMENT '用户电话',
  `cardNo` varchar(100) DEFAULT NULL COMMENT '身份证号码',
  `banknumber` varchar(100) DEFAULT NULL COMMENT '银行卡号',
  `sex` varchar(100) DEFAULT '男' COMMENT '性别',
  `age` int(11) DEFAULT '0' COMMENT '年龄',
  `occupation` varchar(100) DEFAULT '其他' COMMENT '职业',
  `income` int(11) DEFAULT '0' COMMENT '收入',
  `address` varchar(100) DEFAULT NULL COMMENT '所在地',
  `basic` int(11) DEFAULT '0' COMMENT '基本信息状态',
  `quota` int(11) DEFAULT '0' COMMENT '借款额度',
  `quotastatus` int(11) DEFAULT '0' COMMENT '借款状态',
  `head` varchar(100) DEFAULT NULL COMMENT '头像 图片表file_id',
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `p_user` */

insert  into `p_user`(`id`,`username`,`loginpassword`,`paypassword`,`salt`,`realname`,`phone`,`cardNo`,`banknumber`,`sex`,`age`,`occupation`,`income`,`address`,`basic`,`quota`,`quotastatus`,`head`,`createdate`) values (9,'19918222565','11bb1419e18ea4f70247fd63a429983e',NULL,'8674ca69f28dc4086a927eebb616291e','曹广辉','19918222565','430482200012266379','6236682960004021055','男',NULL,NULL,NULL,'湖南省衡阳市常宁市',NULL,NULL,NULL,'137aa4a409df4800918cfd7432552fba','2019-12-02 16:24:49'),(10,'19918222515','5fd83285e97c58b1a1c0c1d6a2d47716',NULL,'c3789dcba96fe0a01191eca7bdfd4c9f',NULL,'19918222515',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-02 16:36:38'),(11,'18674736389','ea7cd6c49be358a340249871208e807e',NULL,'c67d8c3658e3724a9e63c695ee4b6f43','曹广辉','18674736389','430482200012266379',NULL,'男',18,'教师',10000,'湖南省衡阳市常宁市',3,NULL,NULL,'6985d462d58e4c29ab31482b8ecb20a6','2019-12-08 14:07:55'),(12,'15274056071','48a93915db13356988f6754533481f98',NULL,'7cdedbf23f96b72e656c06177c835485',NULL,'15274056071',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'2019-12-10 08:24:52'),(13,'17773914768','b65d28b27cb393adc7eec9f286539dba',NULL,'b67cebab89feb4f20de3aec0a034da26','陈鹏飞','17773914768','43052319990915091X','6236682960004021055','男',18,'教师',4000,'湖南省衡阳市常宁市',3,10000,NULL,'20ac5d730a6f4de1b20a86a6b9f85331','2019-12-10 09:37:54');

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `productname` varchar(100) DEFAULT NULL COMMENT '产品名称',
  `pmax` int(11) DEFAULT NULL COMMENT '产品最高额度',
  `pdata` int(11) DEFAULT NULL COMMENT '借款时长',
  `ptype` int(11) DEFAULT NULL COMMENT '产品类型',
  `pinterest` float DEFAULT NULL COMMENT '产品利息',
  `pservice` int(11) DEFAULT NULL COMMENT '产品服务费',
  `ptext` varchar(888) DEFAULT NULL COMMENT '产品基本信息',
  `pstatus` int(11) DEFAULT NULL COMMENT '产品状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `product` */

insert  into `product`(`id`,`productname`,`pmax`,`pdata`,`ptype`,`pinterest`,`pservice`,`ptext`,`pstatus`) values (1,'急好贷',100000,6,1,0.1,102,'急速到账',1),(2,'零活贷',3000,3,2,0.3,50,'好好好',1),(3,'超级贷',100000,3,1,0.1,50,'werwerwerwe',1),(4,'急好贷1',100000,3,1,0.1,50,'tewtetetertertert',1);

/*Table structure for table `re` */

DROP TABLE IF EXISTS `re`;

CREATE TABLE `re` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `repaymentid` int(11) DEFAULT NULL COMMENT '计划表id',
  `reviewid` int(11) DEFAULT NULL COMMENT '审核表id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `re` */

insert  into `re`(`id`,`repaymentid`,`reviewid`) values (1,1,6),(2,2,6),(3,3,6),(4,4,6),(5,5,7),(6,6,7),(7,7,7),(8,8,8),(9,9,10),(10,10,12);

/*Table structure for table `repayment` */

DROP TABLE IF EXISTS `repayment`;

CREATE TABLE `repayment` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `userid` int(11) NOT NULL COMMENT '用户id',
  `ename` varchar(100) DEFAULT NULL COMMENT '客户姓名',
  `phone` varchar(100) DEFAULT NULL COMMENT '用户电话',
  `rdata` int(11) DEFAULT NULL COMMENT '期数',
  `yingmoney` float DEFAULT NULL COMMENT '应还款金额',
  `benmoney` int(11) DEFAULT NULL COMMENT '本金',
  `fmoney` int(11) DEFAULT NULL COMMENT '服务费',
  `pinterest` float DEFAULT NULL COMMENT '产品利息',
  `koudate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '扣款日',
  `huandate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '还款日',
  `status` int(11) DEFAULT NULL COMMENT '状态',
  `zmoney` float DEFAULT NULL COMMENT '账户',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `repayment` */

insert  into `repayment`(`id`,`userid`,`ename`,`phone`,`rdata`,`yingmoney`,`benmoney`,`fmoney`,`pinterest`,`koudate`,`huandate`,`status`,`zmoney`) values (1,11,'曹广辉','18674736389',1,1012.5,3000,50,0.3,'2019-12-09 20:16:23','2020-01-09 11:53:21',2,NULL),(2,11,'曹广辉','18674736389',1,1012.5,3000,50,0.3,'2019-12-09 20:16:55','2020-02-09 11:53:21',2,1012.5),(3,11,'曹广辉','18674736389',1,1012.5,3000,50,0.3,'2019-12-09 11:58:03','2020-03-11 11:53:21',1,NULL),(4,11,'曹广辉','18674736389',1,1012.5,3000,50,0.3,'2019-12-09 11:58:02','2020-04-11 11:53:21',1,NULL),(5,11,'曹广辉','18674736389',1,1662.5,5000,50,0.3,'2019-12-10 09:58:32','2020-01-09 13:33:03',2,1662.5),(6,11,'曹广辉','18674736389',1,1662.5,5000,50,0.3,'2020-02-09 15:33:03','2020-02-09 13:33:03',1,NULL),(7,11,'曹广辉','18674736389',1,1662.5,5000,50,0.3,'2020-03-11 15:33:03','2020-03-11 13:33:03',1,NULL),(8,11,'曹广辉','18674736389',1,1662.5,5000,50,0.3,'2020-04-11 15:33:03','2020-04-11 13:33:03',1,NULL),(9,11,'曹广辉','18674736389',4,1402,1000,102,0.1,'2020-04-12 01:17:58','2020-04-11 23:17:58',1,NULL),(10,11,'曹广辉','18674736389',4,4002,3000,102,0.1,'2020-04-12 11:55:15','2020-04-12 09:55:15',1,NULL);

/*Table structure for table `review` */

DROP TABLE IF EXISTS `review`;

CREATE TABLE `review` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `userid` int(11) NOT NULL COMMENT '用户id',
  `ename` varchar(100) DEFAULT NULL COMMENT '客户姓名',
  `phone` varchar(100) DEFAULT NULL COMMENT '用户电话',
  `cardNo` varchar(100) DEFAULT NULL COMMENT '身份证号码',
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '放款时间',
  `jiemoney` int(11) DEFAULT NULL COMMENT '借款金额',
  `fangmoney` int(11) DEFAULT NULL COMMENT '放款金额',
  `pid` int(11) DEFAULT NULL COMMENT '产品id',
  `moneycount` float DEFAULT NULL COMMENT '总还款',
  `status` int(11) DEFAULT NULL COMMENT '状态',
  `qdata` int(11) DEFAULT NULL COMMENT '期数',
  `cid` int(11) DEFAULT NULL COMMENT '产品表',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

/*Data for the table `review` */

insert  into `review`(`id`,`userid`,`ename`,`phone`,`cardNo`,`createdate`,`jiemoney`,`fangmoney`,`pid`,`moneycount`,`status`,`qdata`,`cid`) values (1,1,'zs','12112121212','123123123412122345','2019-12-03 17:06:57',5000,5000,1,55000,2,0,1),(2,2,'ls','13123423212','123234542424234324','2019-12-03 19:09:52',6000,6000,2,6700,1,3,NULL),(6,11,'曹广辉','18674736389','430482200012266379','2019-12-09 11:53:21',3000,3000,2,4050,3,4,2),(7,11,'曹广辉','18674736389','430482200012266379','2019-12-09 13:33:03',5000,5000,2,6650,3,4,3),(8,11,'曹广辉','18674736389','430482200012266379','2019-12-09 13:46:03',1000,1000,2,1450,1,4,NULL),(9,11,'曹广辉','18674736389','430482200012266379','2019-12-09 17:34:34',1000,1000,2,1450,2,4,NULL),(10,11,'曹广辉','18674736389','430482200012266379','2019-12-09 23:17:58',1000,1000,1,1402,3,4,4),(11,13,'陈鹏飞','17773914768','43052319990915091X','2019-12-10 09:51:07',3000,3000,1,4002,2,4,NULL),(12,11,'曹广辉','18674736389','430482200012266379','2019-12-10 09:55:15',3000,3000,1,4002,3,4,5);

/*Table structure for table `t_file` */

DROP TABLE IF EXISTS `t_file`;

CREATE TABLE `t_file` (
  `file_id` varchar(32) NOT NULL,
  `real_name` varchar(50) NOT NULL,
  `content_type` varchar(50) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_file` */

insert  into `t_file`(`file_id`,`real_name`,`content_type`) values ('137aa4a409df4800918cfd7432552fba','hui.jpg','image/jpeg'),('145b4fe7b21c45b4a6dba8664e118801','hui.jpg','image/jpeg'),('20ac5d730a6f4de1b20a86a6b9f85331','hui.jpg','image/jpeg'),('3f9899e8d99f4ea8a5e3a0505a1a131a','毛爷爷.png','image/png'),('6985d462d58e4c29ab31482b8ecb20a6','hui.jpg','image/jpeg'),('ce867903759446da9298efcec94cc817','琪.JPG','image/jpeg');

/*Table structure for table `t_sys_permission` */

DROP TABLE IF EXISTS `t_sys_permission`;

CREATE TABLE `t_sys_permission` (
  `perid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID,主键',
  `pername` varchar(100) NOT NULL COMMENT '权限名称',
  `pid` int(11) DEFAULT NULL COMMENT '父编号',
  `permission` varchar(100) DEFAULT NULL COMMENT '权限字符串：例如：system:user:create:1',
  PRIMARY KEY (`perid`)
) ENGINE=InnoDB AUTO_INCREMENT=7004 DEFAULT CHARSET=utf8;

/*Data for the table `t_sys_permission` */

insert  into `t_sys_permission`(`perid`,`pername`,`pid`,`permission`) values (10,'产品管理',-1,NULL),(20,'审批管理',-1,NULL),(30,'合同管理',-1,NULL),(40,'放款管理',-1,NULL),(50,'贷后管理',-1,NULL),(60,'安全管理',-1,NULL),(70,'数据管理',-1,NULL),(1001,'产品信息',10,'/back/doProduct'),(2001,'审核任务',20,'/back/doExamine'),(2002,'我的审批任务',20,'/back/doMyExamine'),(3001,'合同申请',30,'/back/doContract'),(4001,'放款复核',40,'/back/doReview'),(5001,'正常扣款',50,'/back/doDeduction'),(5002,'逾期管理',50,NULL),(6001,'角色管理',60,'/back/doRole'),(6002,'用户管理',60,'/back/doUser'),(7001,'字典管理',70,'/back/doDict'),(7002,'财务管理',70,'/Finance/query');

/*Table structure for table `t_sys_role` */

DROP TABLE IF EXISTS `t_sys_role`;

CREATE TABLE `t_sys_role` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色ID,主键',
  `rolename` varchar(100) NOT NULL COMMENT '角色名称',
  `description` varchar(100) DEFAULT NULL COMMENT '角色描述',
  PRIMARY KEY (`roleid`),
  UNIQUE KEY `rolename` (`rolename`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `t_sys_role` */

insert  into `t_sys_role`(`roleid`,`rolename`,`description`) values (1,'管理员',NULL),(2,'平台管理员',NULL),(3,'审核员',NULL),(4,'审核组长',NULL),(5,'财务',NULL),(6,'催收人员',NULL),(7,'催收组长',NULL);

/*Table structure for table `t_sys_role_permission` */

DROP TABLE IF EXISTS `t_sys_role_permission`;

CREATE TABLE `t_sys_role_permission` (
  `roleid` int(11) NOT NULL COMMENT '角色ID',
  `perid` int(11) NOT NULL COMMENT '权限ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_sys_role_permission` */

/*Table structure for table `t_sys_user` */

DROP TABLE IF EXISTS `t_sys_user`;

CREATE TABLE `t_sys_user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户ID,主键',
  `username` varchar(10) NOT NULL COMMENT '用户账号',
  `PASSWORD` varchar(32) NOT NULL COMMENT '用户密码=MD5+盐加密',
  `salt` varchar(32) NOT NULL COMMENT '盐',
  `createdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建日期',
  `status` int(11) DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `t_sys_user` */

insert  into `t_sys_user`(`userid`,`username`,`PASSWORD`,`salt`,`createdate`,`status`) values (1,'admin','c3b3ac764e1dbf4a1e4483f42c7140cb','af0111353776182a4f166e1d49a7dd2f','2018-11-26 15:02:42',2),(2,'zhangsan','9c917b6f860eeb24361c75f27a236d6b','bcdf6f5c2237bdb440684b6c4ce943d4','2018-11-28 16:44:33',1),(3,'zs','87be4a4d401a986add6a8b6a57653b83','173b5f01ca24ac395d5f95124c864c4d',NULL,2),(4,'ls','440079777e3482cf7b0ae4b517996fe2','5437e7b437455ba1cb30f1b316c936da','2019-11-25 15:30:06',2),(5,'libiao','7e2916e92ea5273b33aec421f882a198','02fa3722e1b1b6fcbd4a9750292b6932','2019-11-25 15:53:32',2),(6,'hui','4694b759d9ccca8cf5a60d9be49e12d7','7944ae4c8895d178bf206d8f74bc06e9','2019-11-28 14:24:08',1);

/*Table structure for table `t_sys_user_role` */

DROP TABLE IF EXISTS `t_sys_user_role`;

CREATE TABLE `t_sys_user_role` (
  `urid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID,主键',
  `userid` int(11) NOT NULL COMMENT '用户ID',
  `roleid` int(11) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`urid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `t_sys_user_role` */

insert  into `t_sys_user_role`(`urid`,`userid`,`roleid`) values (1,1,1),(2,2,2),(3,3,3),(4,4,7),(5,5,3),(6,6,4);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
